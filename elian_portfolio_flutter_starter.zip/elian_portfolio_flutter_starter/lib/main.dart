import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';

import 'data/experience_data.dart';
import 'data/project_data.dart';

// Contact email constant
const String contactEmail = 'elian.alkadar@gmail.com';

void main() {
  runApp(const ElianApp());
}

class ElianApp extends StatelessWidget {
  const ElianApp({super.key});

  @override
  Widget build(BuildContext context) {
    final router = GoRouter(
      routes: [
        GoRoute(path: '/', builder: (_, __) => const HomePage()),
        GoRoute(path: '/experience', builder: (_, __) => const ExperiencePage()),
        GoRoute(path: '/projects', builder: (_, __) => const ProjectsPage()),
        GoRoute(path: '/contact', builder: (_, __) => const ContactPage()),
      ],
      errorBuilder: (_, __) => const HomePage(),
    );

    return MaterialApp.router(
      title: 'Elian Portfolio',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
        brightness: Brightness.dark,
      ),
      routerConfig: router,
    );
  }
}

class ElianScaffold extends StatelessWidget {
  final Widget child;
  final String currentRoute;

  const ElianScaffold({super.key, required this.child, required this.currentRoute});

  @override
  Widget build(BuildContext context) {
    final isLarge = MediaQuery.of(context).size.width > 800;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Elian Al‑Kadar'),
        centerTitle: false,
        actions: isLarge ? _navButtons(context) : null,
      ),
      drawer: isLarge
          ? null
          : Drawer(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  const DrawerHeader(
                    decoration: BoxDecoration(color: Colors.indigo),
                    child: Text('Navigation', style: TextStyle(color: Colors.white, fontSize: 24)),
                  ),
                  ..._navButtons(context),
                ],
              ),
            ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF0D0E14), Color(0xFF1A1C29)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        padding: const EdgeInsets.all(16),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 900),
            child: child,
          ),
        ),
      ),
    );
  }

  List<Widget> _navButtons(BuildContext context) {
    return [
      TextButton(
        onPressed: () => context.go('/'),
        child: const Text('Home'),
      ),
      TextButton(
        onPressed: () => context.go('/experience'),
        child: const Text('Experience'),
      ),
      TextButton(
        onPressed: () => context.go('/projects'),
        child: const Text('Projects'),
      ),
      TextButton(
        onPressed: () => context.go('/contact'),
        child: const Text('Contact'),
      ),
    ];
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ElianScaffold(
      currentRoute: '/',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: const [
          Text('Hello, I\'m Elian',
              style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
          SizedBox(height: 8),
          Text('Graphic Designer • Video Editor • Motion Graphics',
              style: TextStyle(fontSize: 18, color: Colors.white70)),
          SizedBox(height: 16),
          Text(
            'I design clean visuals and engaging videos for broadcast, print and social media. Explore my experience, projects and get in touch.',
            style: TextStyle(fontSize: 16, color: Colors.white60),
          ),
        ],
      ),
    );
  }
}

class ExperiencePage extends StatelessWidget {
  const ExperiencePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ElianScaffold(
      currentRoute: '/experience',
      child: ListView.builder(
        shrinkWrap: true,
        itemCount: experiences.length,
        itemBuilder: (context, index) {
          final exp = experiences[index];
          return Card(
            color: Theme.of(context).colorScheme.surface.withOpacity(0.1),
            margin: const EdgeInsets.symmetric(vertical: 8),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${exp.role} – ${exp.company}',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text(exp.period, style: const TextStyle(color: Colors.white60)),
                  const SizedBox(height: 8),
                  ...exp.bullets.map((b) => Padding(
                        padding: const EdgeInsets.only(bottom: 4),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('• ',
                                style: TextStyle(color: Colors.indigoAccent)),
                            Expanded(child: Text(b)),
                          ],
                        ),
                      ))
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class ProjectsPage extends StatefulWidget {
  const ProjectsPage({super.key});

  @override
  State<ProjectsPage> createState() => _ProjectsPageState();
}

class _ProjectsPageState extends State<ProjectsPage> {
  String? activeCategory;
  @override
  Widget build(BuildContext context) {
    final categories = {
      for (var p in projects) p.category
    }.toList()
      ..sort();
    final filtered = activeCategory == null
        ? projects
        : projects.where((p) => p.category == activeCategory).toList();

    return ElianScaffold(
      currentRoute: '/projects',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 8,
            children: [
              ChoiceChip(
                label: const Text('All'),
                selected: activeCategory == null,
                onSelected: (_) => setState(() => activeCategory = null),
              ),
              ...categories.map((c) => ChoiceChip(
                    label: Text(c),
                    selected: activeCategory == c,
                    onSelected: (selected) =>
                        setState(() => activeCategory = selected ? c : null),
                  )),
            ],
          ),
          const SizedBox(height: 16),
          Expanded(
            child: LayoutBuilder(
              builder: (context, constraints) {
                final crossAxisCount = (constraints.maxWidth / 300)
                    .floor()
                    .clamp(1, 3);
                return GridView.builder(
                  itemCount: filtered.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: crossAxisCount,
                    childAspectRatio: 1.4,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                  ),
                  itemBuilder: (context, index) {
                    final p = filtered[index];
                    return Card(
                      color: Theme.of(context)
                          .colorScheme
                          .surface
                          .withOpacity(0.1),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(p.category,
                                style: const TextStyle(
                                    fontSize: 12, color: Colors.white60)),
                            const SizedBox(height: 4),
                            Text(p.title,
                                style:
                                    const TextStyle(fontWeight: FontWeight.bold)),
                            const SizedBox(height: 8),
                            Expanded(
                              child: Text(p.description,
                                  style: const TextStyle(color: Colors.white70)),
                            ),
                            Wrap(
                              spacing: 4,
                              runSpacing: -8,
                              children: p.tags
                                  .map((tag) => Chip(
                                        label: Text(tag),
                                        materialTapTargetSize:
                                            MaterialTapTargetSize.shrinkWrap,
                                        backgroundColor: Theme.of(context)
                                            .colorScheme
                                            .surfaceVariant
                                            .withOpacity(0.2),
                                      ))
                                  .toList(),
                            ),
                            const SizedBox(height: 8),
                            if (p.links != null)
                              Wrap(
                                spacing: 8,
                                children: p.links!
                                    .map((l) => TextButton(
                                          onPressed: () async {
                                            final uri = Uri.parse(l.url);
                                            if (await canLaunchUrl(uri)) {
                                              await launchUrl(uri);
                                            }
                                          },
                                          child: Text(l.label),
                                        ))
                                    .toList(),
                              ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ElianScaffold(
      currentRoute: '/contact',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Get in touch',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text('Email: $contactEmail',
              style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 4),
          const Text('Location: Homs, Syria',
              style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () async {
              final uri = Uri.parse('mailto:$contactEmail');
              if (await canLaunchUrl(uri)) {
                await launchUrl(uri);
              }
            },
            child: const Text('Send a message'),
          ),
        ],
      ),
    );
  }
}
