class ProjectLink {
  final String label;
  final String url;
  const ProjectLink({required this.label, required this.url});
}

class Project {
  final String title;
  final String category;
  final String description;
  final List<String> tags;
  final List<ProjectLink>? links;

  const Project({
    required this.title,
    required this.category,
    required this.description,
    required this.tags,
    this.links,
  });
}

// Projects data for the portfolio
const List<Project> projects = [
  Project(
    title: 'Broadcast Social Package',
    category: 'Social',
    description:
        'A modular template set for fast newsroom publishing: covers, lower‑thirds, and reels.',
    tags: ['PS', 'AI', 'AE', 'Social'],
    links: [ProjectLink(label: 'Case Study', url: 'https://example.com')],
  ),
  Project(
    title: 'Magazine Layout System',
    category: 'Editorial',
    description:
        'A clean grid + typography system for multi‑issue consistency and faster production.',
    tags: ['InDesign', 'Typography', 'Prepress'],
    links: [ProjectLink(label: 'Preview', url: 'https://example.com')],
  ),
  Project(
    title: 'Motion Opener',
    category: 'Motion',
    description:
        'Short animated opener with bold type and smooth transitions for digital segments.',
    tags: ['After Effects', 'Motion', 'Sound'],
    links: [ProjectLink(label: 'Demo', url: 'https://example.com')],
  ),
];
