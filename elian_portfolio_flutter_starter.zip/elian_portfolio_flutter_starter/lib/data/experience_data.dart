class ExperienceEntry {
  final String role;
  final String company;
  final String period;
  final List<String> bullets;

  const ExperienceEntry({
    required this.role,
    required this.company,
    required this.period,
    required this.bullets,
  });
}

// Experience data based on Elian's CV
const List<ExperienceEntry> experiences = [
  ExperienceEntry(
    role: 'Graphic Designer & Video Editor',
    company: 'RT TV News Channel',
    period: 'Nov 2023 – Present',
    bullets: [
      'Produced & edited 150+ video segments (Premiere Pro, After Effects).',
      'Designed 200+ digital assets (thumbnails, posters, logos, motion graphics).',
      'Optimized videos for social platforms and improved engagement.',
    ],
  ),
  ExperienceEntry(
    role: 'Freelance Graphic Designer',
    company: 'Excel Magazine (Dubai, UAE)',
    period: 'Jun 2024 – Dec 2024',
    bullets: [
      'Designed 6+ full magazine issues (50–80 pages each).',
      'Created 100+ marketing & social media graphics.',
      'Oversaw print‑ready delivery and pre‑press quality.',
    ],
  ),
  ExperienceEntry(
    role: 'Graphic Design Trainer (Part‑time)',
    company: 'HDISC',
    period: 'Sep 2021 – Dec 2023',
    bullets: [
      'Delivered 200+ hours of training (Adobe tools + design principles).',
      'Guided students through real projects and industry workflows.',
    ],
  ),
  ExperienceEntry(
    role: 'Graphic Designer',
    company: 'Christian Hope Center',
    period: 'Apr 2019 – Feb 2022',
    bullets: [
      'Designed 300+ marketing assets and social media visuals.',
      'Supported filming/editing and campaign creative direction.',
    ],
  ),
];
